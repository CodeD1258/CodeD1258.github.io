package com.example.sensormanager;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class InventoryActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private RecyclerView recyclerView;
    private InventoryAdapter adapter;
    private EditText itemNameInput, itemQtyInput, itemLocationInput;
    private Button btnAddItem, btnSmsPage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        // Initialize Database
        dbHelper = new DatabaseHelper(this);

        // Initialize UI components
        recyclerView = findViewById(R.id.recyclerViewInventory);
        itemNameInput = findViewById(R.id.editTextItemName);
        itemQtyInput = findViewById(R.id.editTextItemQty);
        itemLocationInput = findViewById(R.id.editTextItemLocation);
        btnAddItem = findViewById(R.id.buttonAddItem);
        btnSmsPage = findViewById(R.id.buttonSmsPage);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Load and display data
        loadInventoryData();

        // Add item button
        btnAddItem.setOnClickListener(v -> {
            String name = itemNameInput.getText().toString().trim();
            String qtyText = itemQtyInput.getText().toString().trim();
            String location = itemLocationInput.getText().toString().trim();

            if (name.isEmpty() || qtyText.isEmpty() || location.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            int qty;
            try {
                qty = Integer.parseInt(qtyText);
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Quantity must be a number", Toast.LENGTH_SHORT).show();
                return;
            }

            if (dbHelper.addItem(name, qty, location)) {
                Toast.makeText(this, "Item added!", Toast.LENGTH_SHORT).show();
                itemNameInput.setText("");
                itemQtyInput.setText("");
                itemLocationInput.setText("");
                loadInventoryData();
            } else {
                Toast.makeText(this, "Failed to add item", Toast.LENGTH_SHORT).show();
            }
        });

        // Navigate to SMS permissions screen
        btnSmsPage.setOnClickListener(v -> {
            Intent intent = new Intent(InventoryActivity.this, SmsManagerActivity.class);
            startActivity(intent);
        });
    }

    private void loadInventoryData() {
        Cursor cursor = dbHelper.searchItems("");
        List<InventoryItem> itemList = new ArrayList<>();

        if (cursor.moveToFirst()) {
            do {
                int idIndex = cursor.getColumnIndex("item_id");
                int nameIndex = cursor.getColumnIndex("item_name");
                int qtyIndex = cursor.getColumnIndex("quantity");
                int locationIndex = cursor.getColumnIndex("location");

                // Only proceed if indices are valid
                if (idIndex != -1 && nameIndex != -1 && qtyIndex != -1 && locationIndex != -1) {
                    int id = cursor.getInt(idIndex);
                    String name = cursor.getString(nameIndex);
                    int qty = cursor.getInt(qtyIndex);
                    String location = cursor.getString(locationIndex);
                    itemList.add(new InventoryItem(id, name, qty, location));
                }
            } while (cursor.moveToNext());
        }
        cursor.close();

        // Set adapter
        adapter = new InventoryAdapter(this, itemList, dbHelper);
        recyclerView.setAdapter(adapter);
    }
}
